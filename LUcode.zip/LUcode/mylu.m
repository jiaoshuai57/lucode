function [L, U] = mylu(A)
    [m, n] = size(A);
   U(1,1)=A(1,1);
   for i=1:n
       U(1,i)=A(1,i);
       L(i,i)=1;       
   end
   for j=2:n
       L(j,1)=A(j,1)/U(1,1);       
   end
   for k=2:n
       for m=k:n
           U(k,m)=A(k,m)-L(k,1:k-1)*U(1:k-1,m);
           for i=k+1:n
               L(i,k)=(A(i,k)-L(i,1:k-1)*U(1:k-1,k))/U(k,k);
           end
       end
   end
end