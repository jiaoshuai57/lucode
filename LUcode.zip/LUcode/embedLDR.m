function [blocknew]=embedLDR(block,T,lambda,watermark)
A=block;
b=size(block);    %b(1)表示A的行数，b(2)表示A的列数
n=b(1);

%判断矩阵阶次，是否方阵

if b(1)~=b(2)
    
    error('不能分解,非方阵')
    
end



%初始化,定义n阶方阵L，R

L=zeros(n,n);
R=zeros(n,n);

%定义L中的主对角线元素均为1

for i=1:n
    L(i,i)=1;
end

%开始进行Doolittle分解，按照紧凑格式的公式编程

for k=1:n
    for j=k:n
        sum=0;
        for t=1:k-1
            sum=sum+L(k,t)*R(t,j);%求和
        end
        R(k,j)=A(k,j)-sum;    %计算R的第k行元素
    end   
    
    for i=k+1:n
        sum=0;
        for t=1:k-1
            sum=sum+L(i,t)*R(t,k);     %求和
        end
        L(i,k)=(A(i,k)-sum)/R(k,k);    %计算L的第k列
    end  
    
end

E=eye(n);  %定义一个n阶单位矩阵
L=L*E;       %在Matlab中输出L矩阵
D=zeros(n,n);   %定义D为n阶方阵

%构造D为对角矩阵
for i=1:n    
    D(i,i)=R(i,i);    
end

D=D*E;   %在Matlab中输出D矩阵
R=inv(D)*R; %求矩阵R
cols=1;
uavg=(abs(R(2,cols))+abs(R(3,cols)))/2;
%相关系数
if (watermark=='1' )
    R(2,cols)=sign(R(2,cols))*(uavg+T/2);
    R(3,cols)=sign(R(3,cols))*(uavg-T/2);
else
    R(2,cols)=sign(R(2,cols))*(uavg-T/2);
    R(3,cols)=sign(R(3,cols))*(uavg+T/2);
end
blocknew=L*D*E;

