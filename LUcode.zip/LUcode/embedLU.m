clc
clear all;
blocksize=2; %块大小，定义变量%
% blocksize=4;
T=0.075;
load position;
% alpa=0.382;%alpa的作用：确保之间的差保持一个T步长
alpa=0.462;
n=1;

% %% 打开Excel文件
% excel = act xserver('Excel.Application');    % 单引号里的内容不要动
% workbook = excel.Workbooks.Open('D:\matlab\R2021a\bin\testLU\testData.xlsx');     % 单引号里为Excel文件路径
% 
% %% 清空表格内容
% worksheet = workbook.Sheets.Item('Sheet1');  % 单引号里为Sheets的名字
% worksheet.Cells.ClearContents();
% 
% %% 保存并关闭Excel文件
% workbook.Save();
% workbook.Close();
% excel.Quit();

% for alpa=0.302:0.01:0.8
  n=n+1;  
%----------------------------------------------
H='image/safari04.jpg';
W='image/200100732.jpg';
Host=imread(H);
Water=imread(W);
lenw=size(Water,1)*size(Water,2)*8;  %32*32*8=8192 bit
figure(1),subplot(121),imshow(Host),title('Host image');
subplot(122),imshow(Water),title('watermark image');
%--------------------------------------------------
%原始水印处理
for level=1:3
    M=Arnoldmodify(Water(:,:,level),14,0);       %分层置乱
    WaterArnold(:,:,level)=M;
    levelwatermark(level,:)=gainlevelwatermark(M);%置乱后把每个像素值转换为8位二进制序列
end

figure(2),subplot(121),imshow(Water),title('watermark image');
subplot(122),imshow(WaterArnold),title('WaterArnold image');
%--------------------------------------------------
%水印嵌入

load position
psnrval=0;
tic
for level=1:3 
    Hostlevel=double(Host(:,:,level));%取宿主图像每层的像素
    Waterold=levelwatermark(level,:);%取水印图像每层的像素     
    i=1;
    j=1;
    for  counter=1:lenw
          watermark=Waterold(1,counter);
          block1=Hostlevel((i-1)*blocksize+1:(i-1)*blocksize+blocksize,(j-1)*blocksize+1:(j-1)*blocksize+blocksize);           
          block2=Hostlevel((i-1)*blocksize+1:(i-1)*blocksize+blocksize,(j)*blocksize+1:(j)*blocksize+blocksize);    
           
          [blocknew1,blocknew2]=embedWater(block1,block2,T,watermark,alpa,level,counter);
          %测试错误水印块
 
%           [L1,U1]=lu(block1);
%           [L2,U2]=lu(block2);
%           number=abs(abs(L1(3,1))-abs(L2(3,1)));
%           %%写入excel表格------------------------
%           tepm = xlsread('test.xlsx');
%           if size(tepm,1) == 0%是否是空文档
%               mRowRange = '1';
%           else
%               mRowRange = num2str(size(tepm,1)+1);%数组长度转化为字符串
%           end
%           nu_1=strcat('A', mRowRange);%这里的a代表上一次记录数据的行维度+1，永远不会重复记录了，每次都会记录到上一次结果的下一行
%           xlswrite('test.xlsx',number,'sheet1',nu_1);
%           uavg=(abs(L1(3,1))+abs(L2(3,1)))/2;
%           %相关系数 T:基于系数方差的统计特性确定的T。回去求L1(3,1),L2（3，1）的系数差的方差。
%           if (watermark=='1' )
%               L1(3,1)=sign(L1(3,1))*(uavg+T*alpa); 
%               L2(3,1)=sign(L2(3,1))*(uavg-T*(1-alpa));
%           else
%               L1(3,1)=sign(L1(3,1))*(uavg-T*(1-alpa));
%               L2(3,1)=sign(L2(3,1))*(uavg+T*alpa);
%           end
%           blocknew1=L1*U1;
%           blocknew2=L2*U2;
          Hostlevel((i-1)*blocksize+1:(i-1)*blocksize+blocksize,(j-1)*blocksize+1:(j-1)*blocksize+blocksize)=blocknew1;
          Hostlevel((i-1)*blocksize+1:(i-1)*blocksize+blocksize,(j)*blocksize+1:(j)*blocksize+blocksize)=blocknew2;
          j=j+2;
%           if j>128
          if j>256 %对应blocksize=2
              i=i+1;
              j=1;
          end          
       
    end
    watermarkedim(:,:,level)=Hostlevel;
    ssim(level)=colorssim(watermarkedim(:,:,level),Host(:,:,level));
end
     

toc
hand=figure(n);
imwrite(uint8(watermarkedim),'watermarked.bmp'); 
psnrval=colorpsnr(uint8(watermarkedim),Host);
ssimval=(ssim(1)+ssim(2)+ssim(3))/3 ;
subplot(132),imshow('watermarked.bmp'),title([' PSNR=',num2str(psnrval),' ssim=',num2str(ssimval),'alpam=',num2str(alpa)]); 

%水印提取
tic
watermarkedim=double(imread('watermarked.bmp'));
for level=1:3
    wa=watermarkedim(:,:,level);
    ExWater=extractWater(wa,lenw,blocksize);
    wateronedim(level,:)=ExWater;
end
toc
%--------------------------------------------------
%水印恢复
extractlevelwatermark=watermarkrestore(wateronedim);
%求BER

q=0;
for level=1:3
    for i=1:lenw
        if wateronedim(level,i)~=levelwatermark(level,i)
            q=q+1;
        end
    end
end
ber=q/(lenw*3);

imwrite(uint8(extractlevelwatermark),'extrwater.bmp')
ncval=colornc(uint8(extractlevelwatermark),uint8(Water));
subplot(133),imshow( uint8(extractlevelwatermark)),title(['Extracted Watermark nc=',num2str(ncval)]);
% % %%写入excel表格------------------------
% tepm = xlsread('testData.xlsx');
% if size(tepm,1) == 0%是否是空文档
%     mRowRange = '1';
% else
%     mRowRange = num2str(size(tepm,1)+1);%数组长度转化为字符串
% end
% psnr = strcat('A', mRowRange);%这里的a代表上一次记录数据的行维度+1，永远不会重复记录了，每次都会记录到上一次结果的下一行
% ssim_t = strcat('B', mRowRange);
% alpa_t = strcat('C',mRowRange);
% nc = strcat('D',mRowRange);
% 
% xlswrite('testData.xlsx',psnrval,'sheet1',psnr);
% xlswrite('testData.xlsx',ssimval,'sheet1',ssim_t);
% xlswrite('testData.xlsx',alpa,'sheet1',alpa_t);
% xlswrite('testData.xlsx',ncval,'sheet1',nc);

% name=['Sresize','by',num2str(n),'307','.fig'];
% saveas(hand,name)
% end %for alph参数
%---------------------------------------------------
% % % % % %算法测试
%  watermarkedim=imread('watermarked.bmp');
% for Q=4
% % JPEG
%  [wateronedim,control_group]=attack_JPGE(Q,watermarkedim,lenw,blocksize);%  Q=40:30:70
% % JPEG2000
%   [wateronedim,control_group]=attack_JPGE2000(Q,watermarkedim,lenw,blocksize); %Q=1:10
% % Median filtering  中值滤波/维纳滤波
% [wateronedim,control_group]=attack_Medianfiltering(Q,watermarkedim,lenw,blocksize);
% % salt & pepper Q=1/gaussion  
% [wateronedim,wb]=attack_salt_gaussian(Q,watermarkedim,lenw,blocksize);
% % resize 放大
% [wateronedim,control_group]=attack_resize(Q,watermarkedim,lenw,blocksize); % 0.5/4
%均值滤波/高斯滤波
%  [wateronedim,control_group]=attack_average(Q,watermarkedim,lenw,blocksize);
% % cropping 剪切   
% [wateronedim,control_group]=attack_cropping(Q,watermarkedim,lenw,blocksize);  
% % rotate 旋转   Q=15比不过
% [wateronedim,control_group]=attack_rotate(Q,watermarkedim,lenw,blocksize); 
% % Translation 平移   
%  Q=-10;P=-10;
%  Q=20; P=40;
% [wateronedim,control_group]=attack_translating(Q,P,watermarkedim,lenw,blocksize); 

% 水印恢复
% 
% extractlevelwatermark=watermarkrestore(wateronedim);
% for level=1:3
%     for i=1:lenw
%         if wateronedim(level,i)~=levelwatermark(level,i)
%             q=q+1;
%         end
%     end
% end
% ber=q/(lenw*3);
% q=0;
% % QQ=5
% psnrval=colorpsnr(watermarkedim,Host);
% imwrite(uint8(extractlevelwatermark),'translating.bmp')
% ncval=colornc(uint8(extractlevelwatermark),uint8(Water));
% hand=figure(Q);
% subplot(121),imshow( uint8(extractlevelwatermark)),title(['Extracted Watermark nc/ber=',num2str(ncval),'/',num2str(ber)]);
% subplot(122),imshow(uint8(control_group)),title([num2str(Q),'  PSNRr=',num2str(psnrval)]);%jpge,jpge2000,medianf,resize，cropping
% % subplot(122),imshow(uint8(wb)),title(['D=',num2str(Q*0.01),'  PSNRr=',num2str(psnrval)]);%椒盐噪声
% % subplot(122),imshow(uint8(wb)),title(['V=',num2str(0.0001*Q),'  PSNRr=',num2str(psnrval)]);%高斯噪声
% name=[H(1:length(H)-4),'JPEG_', num2str(Q),W(1:length(W)-4),'.fig'];
% % saveas(hand,name);
% resultJPEG(1,Q)=psnrval;%JPGE时，要Q/10
% resultJPEG(2,Q)=ncval;%同上
% % end%对应for
% 
% % 求BER
% q=0;

