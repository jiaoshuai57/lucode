function [wateronedim,control_group]=attack_average(Q,watermarkedim,lenw,blocksize)
   
for level=1:3
%         filter=fspecial('average',[Q,Q]);  %均值
        filter=fspecial('gaussian',[Q,Q]);  %高斯
        wb=imfilter(watermarkedim(:,:,level),filter);
        control_group(:,:,level)=wb;
        wa=double(wb);
        ExWater=extractWater(wa,lenw,blocksize);
        wateronedim(level,:)=ExWater;   
    end
end

