function [wateronedim,wb]=attack_salt_gaussian(Q,watermarkedim,lenw,blocksize)
 wb=imnoise(watermarkedim,'salt & pepper',0.01*Q);  %salt & pepper椒盐噪声  J = IMNOISE(I,'salt & pepper',D)
%   wb=imnoise(watermarkedim,'gaussian',0,0.0001*Q);    %gausian高斯噪声  J = IMNOISE(I,'gaussian',M,V)
                                             %M为均值 V为方差
   imwrite(wb,'temp.bmp');

      for level=1:3
         wa=double(wb(:,:,level));
         ExWater=extractWater(wa,lenw,blocksize);
         wateronedim(level,:)=ExWater;         
      end
end

