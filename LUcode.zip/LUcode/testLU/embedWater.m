function [blocknew1,blocknew2]=embedWater(block1,block2,T,watermark,alpa,level,counter)

%           [L1,U1]=mylu(block1);
%           [L2,U2]=mylu(block2);     
% 
%           uavg=(abs(L1(3,1))+abs(L2(3,1)))/2;
%           %相关系数 T:基于系数方差的统计特性确定的T。回去求L1(3,1),L2（3，1）的系数差的方差。
%           if (watermark=='1') 
%               L1(3,1)=sign(L1(3,1))*(uavg+T*alpa); 
%               L2(3,1)=sign(L2(3,1))*(uavg-T*(1-alpa));
%           else
%               L1(3,1)=sign(L1(3,1))*(uavg-T*(1-alpa));                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
%               L2(3,1)=sign(L2(3,1))*(uavg+T*alpa);
%           end
% 
%           blocknew1=L1*U1;
%           blocknew2=L2*U2;   
%     
T1=T*alpa;
T2=T*(1-alpa);
block11=block1;
block22=block2;
 if (watermark=='1')
          for j=1:2

          block11(2,j)=block1(2,j)+( (block2(2,1)/(2*block2(1,1))) + T1 - (block1(2,1)/(2*block1(1,1))) )*block1(1,j);
          block22(2,j)=block2(2,j)+( (block1(2,1)/(2*block1(1,1))) - T2 - (block2(2,1)/(2*block2(1,1))) )*block2(1,j);
          end
 else
          for j=1:2

          block11(2,j)=block1(2,j)+( (block2(2,1)/(2*block2(1,1))) - T2 - (block1(2,1)/(2*block1(1,1))) )*block1(1,j);
          block22(2,j)=block2(2,j)+( (block1(2,1)/(2*block1(1,1))) + T1 - (block2(2,1)/(2*block2(1,1))) )*block2(1,j);
         
          end
  end
            
      blocknew1=block11;
      blocknew2=block22;
end

