clear;
block1=[15,14,13,14;15,14,13,14;15.3528000000000,14.3292800000000,14.3057600000000,15.3292800000000;15,15,15,16];%后
block2=[14,14,14,14;14,14,14,14;14.4528000000000,13.4892800000000,13.4892800000000,14.4528000000000;15,14,14,16];
block11=[15,14,13,14;15,14,13,14;15,14,14,15;15,15,15,16];%前
block22=[14,14,14,14;14,14,14,14;15,14,14,15;15,14,14,16];
watermark='1';
T=0.06;
alpa=0.392;
% [L1,U1]=lu(block1);
% [L2,U2]=lu(block2);
% [L1,U1]=lu(block11);
% [L2,U2]=lu(block22);
     [L1,U1]=lu(block1);
     [L2,U2]=lu(block2);
uavg=(abs(L1(3,1))+abs(L2(3,1)))/2;
% 相关系数 T:基于系数方差的统计特性确定的T。回去求L1(3,1),L2（3，1）的系数差的方差。
if (watermark=='1')  %&&(L1(3,1)<=L2(3,1))
%                   L1(3,1)=(L1(3,1)+L2(3,1))/2+T;
%                   L2(3,1)=(L1(3,1)+L2(3,1))/2-T;
    L1(3,1)=(uavg+T*alpa);
    L2(3,1)=(uavg-T*(1-alpa));
else
%               end
%               if (watermark=='0')&&(L1(3,1)>L2(3,1))
                   L1(3,1)=(L1(3,1)+L2(3,1))/2-T;
                   L2(3,1)=(L1(3,1)+L2(3,1))/2+T;
    L1(3,1)=(uavg-T*(1-alpa));
    L2(3,1)=(uavg+T*alpa);
end
blocknew1=L1*U1
blocknew2=L2*U2
[Lnew1,U1]=lu(blocknew1);
[Lnew2,U2]=lu(blocknew2);
if  abs(Lnew1(3,1)) >= abs(Lnew2(3,1))
    watermarkextr='1';
else
    watermarkextr='0';
end



%  clear;
% % block1=[15,14,13,14;15,14,13,14;15.3528000000000,14.3292800000000,14.3057600000000,15.3292800000000;15,15,15,16];%后
% % block2=[14,14,14,14;14,14,14,14;14.4528000000000,13.4892800000000,13.4892800000000,14.4528000000000;15,14,14,16];
% block1=[15,14,13,14;15,14,13,14;15,14,14,15;15,15,15,16];%前
% block2=[14,14,14,14;14,14,14,14;15,14,14,15;15,14,14,16];
% block11=[15,14,13,14;15,14,13,14;15,14,14,15;15,15,15,16];%前
% block22=[14,14,14,14;14,14,14,14;15,14,14,15;15,14,14,16];
% watermark='1';
% T=0.06;
% alpa=0.392;
% T1=T*alpa;
% T2=T*(1-alpa);
%  if (watermark=='1')
%           for j=1:4
% %              block11(3,j)=block1(3,j)+( ((block1(3,1)*block1(1,j))/(2*block1(1,1))) + ((block2(3,1)*block1(1,j))/(2*block2(1,1))) + (T1*block1(1,j)) - ((block1(3,1)*block1(1,j))/block1(1,1)) );               
% %              block22(3,j)=block2(3,j)+( ((block2(3,1)*block2(1,j))/(2*block2(1,1))) + ((block1(3,1)*block2(1,j))/(2*block1(1,1))) - (T2*block2(1,j)) - ((block2(3,1)*block2(1,j))/block2(1,1)) );               
%           block1(3,j)=block1(3,j)+( (block2(3,1)/(2*block2(1,1))) + T1 - (block1(3,1)/(2*block1(1,1))) )*block1(1,j);
%           block2(3,j)=block2(3,j)+( (block1(3,1)/(2*block1(1,1))) - T2 - (block2(3,1)/(2*block2(1,1))) )*block2(1,j);
%           end
%  else
%           for j=1:4
% %               block11(3,j)=block1(3,j)+( ((block1(3,1)*block1(1,j))/(2*block1(1,1))) + ((block2(3,1)*block1(1,j))/(2*block2(1,1))) - (T2*block1(1,j)) - ((block1(3,1)*block1(1,j))/block1(1,1)) );               
% %               block22(3,j)=block2(3,j)+( ((block2(3,1)*block2(1,j))/(2*block2(1,1))) + ((block1(3,1)*block2(1,j))/(2*block1(1,1))) + (T1*block2(1,j)) - ((block2(3,1)*block2(1,j))/block2(1,1)) );               
%           block1(3,j)=block1(3,j)+( (block2(3,1)/(2*block2(1,1))) - T2 - (block1(3,1)/(2*block1(1,1))) )*block1(1,j);
%           block2(3,j)=block2(3,j)+( (block1(3,1)/(2*block1(1,1))) + T1 - (block2(3,1)/(2*block2(1,1))) )*block2(1,j);
%           end
%   end
%             
%       blocknew1=block1
%       blocknew2=block2
%            
%       Lnew1(3,1)=blocknew1(3,1)/blocknew1(1,1);
%       Lnew2(3,1)=blocknew2(3,1)/blocknew2(1,1);
% if  abs(Lnew1(3,1)) >= abs(Lnew2(3,1))
%     watermarkextr='1';
% else
%     watermarkextr='0';
% end