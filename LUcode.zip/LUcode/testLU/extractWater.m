function [ExWater] = extractWater(wa,lenw,blocksize)
i=1;
j=1;
for  counter=1:lenw
    block1=wa((i-1)*blocksize+1:(i-1)*blocksize+blocksize,(j-1)*blocksize+1:(j-1)*blocksize+blocksize);
    block2=wa((i-1)*blocksize+1:(i-1)*blocksize+blocksize,(j)*blocksize+1:(j)*blocksize+blocksize);

%     [L1,U1]=mylu(block1);
%     [L2,U2]=mylu(block2);
      L1(2,1)=block1(2,1)/block1(1,1);
      L2(2,1)=block2(2,1)/block2(1,1);
    if  abs(L1(2,1)) <= abs(L2(2,1))
        watermark='0';
    else
        watermark='1';
    end
    ExWater(1,counter)=watermark;
    j=j+2;
   %           if j>128
     if j>256 
        i=i+1;
        j=1;
    end
end
end

