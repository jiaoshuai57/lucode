clc
clear all;
blocksize=3; %块大小，定义变量%
H={'image/clinmill.jpg'};%'peppers.jpg','baboon.jpg','bear.jpg','kid.jpg' 
%实验奇偶块对应位置的nc系数
for hosti=1:length(H)
    Host=H{hosti};
    Host=imread(Host);
    for level=1:3 
    Hostlevel=double(Host(:,:,level));%取宿主图像每层的像素
    count=1;
    count2=1;
    for i=1:128
        for j=1:128
            block=Hostlevel((i-1)*blocksize+1:(i-1)*blocksize+blocksize,(j-1)*blocksize+1:(j-1)*blocksize+blocksize); 
            [L,U]=lu(block);
            result = mod(j, 2);%奇数 1 偶数 0
            if result == 0
                num=1;
                for x=1:3
                    for y=1:3
                       S1(num,count)=L(x,y) ;
                       num=num+1;
                    end                    
                end
                count=count+1;
            else
                num=1;
                for x=1:3
                    for y=1:3
                       S2(num,count2)=L(x,y) ;
                       num=num+1;
                    end                    
                end
                count2=count2+1;
            end    
        end
    end
    for m=1:3
       NC(level,m)=new_color_nc(S1(m,:),S2(m,:));
    end
    end
    for m=1:3
       NCavrge(m)=sum(NC(:,m))/3;
    end
end
% Host=imread(H);
% for level=1:3 
%     Hostlevel=double(Host(:,:,level));%取宿主图像每层的像素
%     count=1;
%     count2=1;
%     for i=1:128
%         for j=1:128
%             block=Hostlevel((i-1)*blocksize+1:(i-1)*blocksize+blocksize,(j-1)*blocksize+1:(j-1)*blocksize+blocksize); 
%             [L,U]=lu(block);
%             result = mod(j, 2);%奇数 1 偶数 0
%             if result == 0
%                 num=1;
%                 for x=1:4
%                     for y=1:4
%                        S1(num,count)=L(x,y) ;
%                        num=num+1;
%                     end                    
%                 end
%                 count=count+1;
%             else
%                 num=1;
%                 for x=1:4
%                     for y=1:4
%                        S2(num,count2)=L(x,y) ;
%                        num=num+1;
%                     end                    
%                 end
%                 count2=count2+1;
%             end    
%         end
%     end
%     for m=1:16
%        NC(level,m)=new_color_nc(S1(m,:),S2(m,:));
%     end
% end