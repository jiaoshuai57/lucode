function [correctedwatermarkedimg,attacktypes,totalcorrectetime]=CorrectingGeometricAttacks(attackedimg,M,N)
% %   2019.12.10���    %% 2020.03.21�޶�������һ����������Ϊ���Ͻǣ������������
%------------------��������attacktype=1...8�ֱ��ʾ��---------------------------------%
% 1:Scaling attack;        2:Enlarge attack         3:No attack or image transformation
% 4:Rotation attack;      5:Translation attack;   6:Horizontal shearing attack;
% 7:Vertical shearing attack;        8:Affine transform attack
%-------------------------------------------------------------------------------------------%
attacktypes={'Scaling attack','Enlarge attack','No attack or image transformation','Rotation attack','Translation attack','Horizontal shearing attack','Vertical shearing attack','Affine transform attack'};
t1=clock;
[attacktype,cornerpoint,~,~,~]=JudgingAttackType(attackedimg,M,N);
if      attacktype==1 %��С����
    correctedwatermarkedimg=RemovingBlackEdges(attackedimg,M,N);
elseif attacktype==2 %�Ŵ󹥻�
    correctedwatermarkedimg=RemovingBlackEdges(attackedimg,M,N);
elseif attacktype==3 %�޹���
    correctedwatermarkedimg=attackedimg;
elseif attacktype==4%��ת����
    havingblackwatermarkedimg=CorrectingRotate(attackedimg,cornerpoint);
    correctedwatermarkedimg=RemovingBlackEdges(havingblackwatermarkedimg,M,N);
elseif attacktype==5%ƽ�ƹ���
    correctedwatermarkedimg=CorrectingTranslate(attackedimg,cornerpoint,5);
elseif attacktype==6 %ˮƽ����
    havingblackwatermarkedimg=CorrectingAffine(attackedimg,cornerpoint,M,N,6);
%     figure();imshow(uint8(havingblackwatermarkedimg));
    correctedwatermarkedimg=RemovingBlackEdges(havingblackwatermarkedimg,M,N);
elseif attacktype==7 %��ֱ����
    havingblackwatermarkedimg=CorrectingAffine(attackedimg,cornerpoint,M,N,7);
%     figure();imshow(uint8(havingblackwatermarkedimg));
    correctedwatermarkedimg=RemovingBlackEdges(havingblackwatermarkedimg,M,N);
elseif attacktype==8 %����任
    havingblackwatermarkedimg=CorrectingAffine(attackedimg,cornerpoint,M,N,8);
%     figure();imshow(uint8(havingblackwatermarkedimg));
    correctedwatermarkedimg=RemovingBlackEdges(havingblackwatermarkedimg,M,N);
end
t2=clock;
totalcorrectetime=etime(t2,t1);
attacktypes=attacktypes{attacktype};
end