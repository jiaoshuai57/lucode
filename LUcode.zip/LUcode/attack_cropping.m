function [wateronedim,control_group]=attack_cropping(Q,watermarkedim,lenw,blocksize)

wb=imread('watermarked.bmp');
%    wb(1:64*Q,1:64*Q,:)=0; % Cropping attack
     wb(64*Q:512,64*Q:512,:)=0;
   imwrite(wb,'temp.bmp');
    for level=1:3   
        control_group(:,:,level)=wb(:,:,level);
        wa=double(wb(:,:,level));
        ExWater=extractWater(wa,lenw,blocksize);
        wateronedim(level,:)=ExWater;   
    end
end