function [attacktype,cornerpoint,edgs,anglesout,anglesin]=JudgingAttackType(attackedimg,M,N)
% 2020.03.21�޶�������һ����������Ϊ���Ͻǣ������������
%---------------2019.12.06���------------------%
%�ж�ͼ��attackedimg�Ĺ�������
%M,N�ֱ�Ϊԭʼͼ�������������
%------------------��������attacktype=1...8�ֱ��ʾ��---------------------------------%
% 1:Scaling attack;        2:Enlarge attack         3:No attack or image transformation
% 4:Rotation attack;      5:Translation attack;   6:Horizontal shearing attack;
% 7:Vertical shearing attack;        8:Affine transform attack
%-------------------------------------------------------------------------------------------%
attacktype=1;
cornerpoint=LocatingVertices(attackedimg);%��λ�ĸ�����
[edgs,anglesout,anglesin]=CalculatingEdgesAngles(cornerpoint);%����ͼ��ı߳�����Ǻ��ڽ�
detaedge=0.01;
detaangle=0.99;
Q2=5;
if abs(anglesin(1)-90)<=detaangle || abs(anglesin(2)-90)<=detaangle %�ж��Ƿ�Ϊ����
    if abs(edgs(1)/N-edgs(2)/M)<=detaedge %�ж��Ƿ�Ϊ������
        if abs(anglesout(1)-90)<=detaangle || abs(anglesout(2)-90)<=detaangle %�Ƿ���ת
            if  1-edgs(1)/N >= detaedge && (abs((cornerpoint(1,1,1)+cornerpoint(1,1,3))/2-M/2)<=Q2 && abs(((cornerpoint(1,2,1)+cornerpoint(1,2,3))/2-N/2))<=Q2 )
                disp('Scaling attack');
                attacktype=1;
            elseif 1-edgs(1)/N < -detaedge
                disp('Enlarge attack');
                attacktype=2;
            elseif  abs(1-edgs(1)/N)<=detaedge 
                disp('No attack or image transformation');
                attacktype=3;
            else
                disp('Translation attack');
                attacktype=5;
            end
        else
            disp('Rotation attack');
            attacktype=4;
        end
    else
        disp('Translation attack');
        attacktype=5;
    end
elseif abs(anglesout(3)-anglesout(1))<=detaangle && anglesout(3)~=0 && anglesout(1)~=0 && anglesout(4)==anglesout(2) && anglesout(4)==90 && min(anglesin)~=max(anglesin) && min(anglesin)~=90
    disp('Horizontal shearing attack');%ˮƽ
    attacktype=6;
elseif anglesout(3)==anglesout(1) && anglesout(3)==0 && abs(anglesout(2)-anglesout(4))<=detaangle && abs(anglesout(2)-90)>detaangle && min(anglesin)~=max(anglesin) && min(anglesin)~=90
    disp('Vertical shearing attack');
    attacktype=7;
elseif abs(anglesout(2)-anglesout(4))<=detaangle && anglesout(2)~=0 && abs(anglesout(3)-anglesout(1))<=detaangle && abs(anglesout(3)-90)>detaangle && min(anglesin)~=max(anglesin) && min(anglesin)~=90
    disp('Affine transform attack');
    attacktype=8;
end
end