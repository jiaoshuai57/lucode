function [wateronedim,control_group]=attack_resize(Q,watermarkedim,lenw,blocksize)
    for level=1:3
        wb=imresize(watermarkedim(:,:,level),Q); %gausian
        wb=imresize(wb,[512 512]);
        control_group(:,:,level)=wb;
        wa=double(wb);
        ExWater=extractWater(wa,lenw,blocksize);
        wateronedim(level,:)=ExWater;   
    end
end

