%Cropping attack ����   ͼ��ֲ㹥��
function [result]=croppingAttack(position,host,watermark,blocksize,watermarked)
 
    waterlen=size(position,2);
    hostr=size(host,1);blocknum=floor(hostr/blocksize);

 
    % 512��25%��128��512��50%��256
    for Q=2:2:4%1:1:4
        ca=watermarked;
%                 ca(1:64*Q,:,:)=255; % Cropping attack 
%         ca(:,1:153,:)=255;%���30%
        ca(1:280,1:280,:)=1;%���Ͻ�30%
%      ca(1:256,1:256,:)=1; %���Ͻ�25
%         ca(:,1:64*Q,:)=0; 
        attacked=double(ca);
%         tic
   
        for waterCount=1:waterlen
            %�ҵ���λ��
            pos=position(waterCount);
            ii=floor((pos-1)/blocknum)+1;jj=mod(pos-1,blocknum)+1;
            for i=1:3
                block(:,:,i)=attacked((ii-1)*blocksize+1:ii*blocksize,(jj-1)*blocksize+1:jj*blocksize,i);
            end
            waterbit=extractWaterqiu(block,blocksize);
% waterbit=extractWater(block,blocksize);
            bwatered(1,waterCount)=waterbit(1);bwatered(2,waterCount)=waterbit(2);bwatered(3,waterCount)=waterbit(3);
        end
%         toc 
        sk1=[0.56823603, 0.00427592, 0.71750067];
        sk2=[0.12516930, 0.56120908, 0.87443383];
        extractwatermark=decry2DLASM(bwatered,sk1,sk2);
%         extractwatermark=watermarkrestore(bwatered);
        ncval=colornc(uint8(extractwatermark),uint8(watermark)); 
         
        result(floor(Q/2),1)=Q; 
        result(floor(Q/2),2)=ncval;
%  figure(1),subplot(121),imshow(ca),title('attacked hostimage');
%   figure(1),subplot(122),imshow(uint8(extractwatermark)),title(['nc=',num2str(ncval)]);
figure(1),imshow(uint8(extractwatermark)),title(['nc=',num2str(ncval)]);
% folder_name='attackfigure';
% file_name=sprintf('Cropping(left30%) NC=%s.jpg',num2str(ncval));
% file_path=fullfile(folder_name,file_name);s
imwrite(uint8(extractwatermark),'Cropping(left25%).jpg');

    end

    
    
    
    
    