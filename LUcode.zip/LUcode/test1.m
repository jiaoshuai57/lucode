clc
clear all;
blocksize=4; %块大小，定义变量%
T=0.03;
lambda=60;
sum1=0;
sum2=0;
load position;
%----------------------------------------------
H='lena.jpg';
W='3073232.tif';
Host=imread(H);
Water=imread(W);
lenw=size(Water,1)*size(Water,2)*8;  %32*32*8=8192 bit
figure(1),subplot(121),imshow(Host),title('Host image');
subplot(122),imshow(Water),title('watermark image');
%--------------------------------------------------
%原始水印处理
for level=1:3
    M=Arnoldmodify(Water(:,:,level),14,0);       %分层置乱
    WaterArnold(:,:,level)=M;
    levelwatermark(level,:)=gainlevelwatermark(M);%置乱后把每个像素值转换为8位二进制序列
end

figure(2),subplot(121),imshow(Water),title('watermark image');
subplot(122),imshow(WaterArnold),title('WaterArnold image');
%--------------------------------------------------
%水印嵌入

load position
psnrval=0;
tic
for level=1:3 
    Hostlevel=double(Host(:,:,level));%取宿主图像每层的像素
    Waterold=levelwatermark(level,:);%取水印图像每层的像素
    for  counter=1:lenw
        i=position(1,counter,level);
        j=position(2,counter,level);
        watermark=Waterold(1,counter);
        block1=Hostlevel((i-1)*blocksize+1:(i-1)*blocksize+blocksize,(j-1)*blocksize+1:(j-1)*blocksize+blocksize);
        if j>128
            i=i+1;
        else
            j=j+1;
        end
        block2=Hostlevel((i-1)*blocksize+1:(i-1)*blocksize+blocksize,(j-1)*blocksize+1:(j-1)*blocksize+blocksize);
        [C1,U1]=lu(block1)
        [C2,U2]=lu(block2)
        maxValue=100; 
        maxPos = [0, 0];
        [m, n] = size(C1);
        % 使用双重循环遍历每个位置
        for x = 1:m
            for y = 1:n
                % 将相同位置的值作差
                if C1(x, y)~=C2(x, y)
                    value = abs(abs(C1(x, y))-abs(C2(x, y)));
                    if value < 0.0001
                        sumValue=0.0001;
                    else
                        sumValue=value;
                    end                
                end
                % 检查是否是最小值
                if sumValue < maxValue
                    % 更新最小值和其位置
                    maxValue = sumValue;
                    maxPos = [x, y];
                end
            end
        end
       uavg=(abs(C1(maxPos(1),maxPos(2)))+abs(C2(maxPos(1),maxPos(2))))/2;
       if (watermark=='1' )
            C1(maxPos(1),maxPos(2))=sign(C1(maxPos(1),maxPos(2)))*(uavg+T/2);
            C2(maxPos(1),maxPos(2))=sign(C2(maxPos(1),maxPos(2)))*(uavg-T/2);
        else 
             C1(maxPos(1),maxPos(2))=sign(C1(maxPos(1),maxPos(2)))*(uavg-T/2);
             C2(maxPos(1),maxPos(2))=sign(C2(maxPos(1),maxPos(2)))*(uavg+T/2);
        end
        blocknew1=C1*U1;
        blocknew2=C2*U2;
        Hostlevel((i-1)*blocksize+1:(i-1)*blocksize+blocksize,(j-1)*blocksize+1:(j-1)*blocksize+blocksize)=blocknew1;
        if j>128
            i=i+1;
        else
            j=j+1;
        end
        Hostlevel((i-1)*blocksize+1:(i-1)*blocksize+blocksize,(j-1)*blocksize+1:(j-1)*blocksize+blocksize)=blocknew2;
        if counter>lenw
            break;
        end
     
    end
    
    watermarkedim(:,:,level)=Hostlevel;
    ssim(level)=colorssim(watermarkedim(:,:,level),Host(:,:,level));
%     imwrite(uint8(Hostlevel),'www.bmp');
%     imwrite(Host(:,:,level),'hhh.bmp');
%     psnrval=psnrval+PSNR('www.bmp','hhh.bmp');
end
toc
imwrite(uint8(watermarkedim),'watermarked.bmp');
%psnrval=PSNR(H,'watermarked.bmp');
psnrval=colorpsnr(uint8(watermarkedim),Host);
ssimval=(ssim(1)+ssim(2)+ssim(3))/3
% figure(3),subplot(131),imshow(Host),title('Original image');
subplot(132),imshow('watermarked.bmp'),title([' PSNR=',num2str(psnrval),' ssim=',num2str(ssimval)]);
% subplot(132),imshow('watermarked.bmp'),title([' PSNR=',num2str(psnrval),' ssim=',num2str(ssim)]);
