function [wateronedim,control_group] = attack_Medianfiltering(Q,watermarkedim,lenw,blocksize)
      for level=1:3
%          wb=medfilt2(watermarkedim(:,:,level),[Q,Q]); %二维中值滤波   
         wb=wiener2(watermarkedim(:,:,level),[Q,Q]); %维纳滤波
         control_group(:,:,level)=wb;
         wa=double(wb);
         ExWater=extractWater(wa,lenw,blocksize);
         wateronedim(level,:)=ExWater;         
      end
end

