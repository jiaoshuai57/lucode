function [blocknew1,blocknew2]=embedWater_k(block1,block2,T,watermark,alpa,level,counter)
 
          L1(3,1)=block1(3,1)/block1(1,1);
          L2(3,1)=block2(3,1)/block2(1,1);




          [L1,U1]=lu(block1);
          [L2,U2]=lu(block2);
          uavg=(abs(L1(3,1))+abs(L2(3,1)))/2;
          %相关系数 T:基于系数方差的统计特性确定的T。回去求L1(3,1),L2（3，1）的系数差的方差。
          if (watermark=='1')  %&&(L1(3,1)<=L2(3,1))
%               L1(3,1)=(L1(3,1)+L2(3,1))/2+T;
%               L2(3,1)=(L1(3,1)+L2(3,1))/2-T;
              L1(3,1)=sign(L1(3,1))*(uavg+T*alpa); 
              L2(3,1)=sign(L2(3,1))*(uavg-T*(1-alpa));
          else
%           end
%           if (watermark=='0')&&(L1(3,1)>L2(3,1))
%                L1(3,1)=(L1(3,1)+L2(3,1))/2-T;
%                L2(3,1)=(L1(3,1)+L2(3,1))/2+T;
              L1(3,1)=sign(L1(3,1))*(uavg-T*(1-alpa));                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
              L2(3,1)=sign(L2(3,1))*(uavg+T*alpa);
          end
%           if level==1&&counter==65
%               L1
%               L2
%               U111=U1
%               U222=U2
%           end
          blocknew1=L1*U1;
          blocknew2=L2*U2;   

end