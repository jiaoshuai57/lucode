function [wateronedim,control_group] = attack_JPGE(Q,watermarkedim,lenw,blocksize)

      for level=1:3
         imwrite(watermarkedim(:,:,level),'temp.bmp','jpg','quality',Q);
         wb=imread('temp.bmp');
         control_group(:,:,level)=wb;
         wa=double(wb);
%          i=1;
%          j=1;
%          for  counter=1:lenw             
%              block1=wa((i-1)*blocksize+1:(i-1)*blocksize+blocksize,(j-1)*blocksize+1:(j-1)*blocksize+blocksize);
%              block2=wa((i-1)*blocksize+1:(i-1)*blocksize+blocksize,(j)*blocksize+1:(j)*blocksize+blocksize);
%              [L1,U1]=lu(block1);
%              [L2,U2]=lu(block2);
%              if  abs(L1(3,1)) >= abs(L2(3,1))
%                  watermark='1';
%              else
%                  watermark='0';
%              end
%              ExWater(1,counter)=watermark;
%              j=j+2;
%              if j>128
%                  i=i+1;
%                  j=1;
%              end
%          end
       ExWater=extractWater(wa,lenw,blocksize);
       wateronedim(level,:)=ExWater;         
      end

end

