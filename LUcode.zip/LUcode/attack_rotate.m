function [wateronedim,control_group]=attack_rotate(Q,watermarkedim,lenw,blocksize)

   temp=RotatingAttack(watermarkedim,Q);
   wb=CorrectingGeometricAttacks(temp,512,512);
    for level=1:3   
        control_group(:,:,level)=wb(:,:,level);
        wa=double(wb(:,:,level));
        ExWater=extractWater(wa,lenw,blocksize);
        wateronedim(level,:)=ExWater;   
    end
end