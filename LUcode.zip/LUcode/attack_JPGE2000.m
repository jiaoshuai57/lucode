function [wateronedim,control_group] = attack_JPGE2000(Q,watermarkedim,lenw,blocksize)
    for level=1:3
    imwrite(watermarkedim(:,:,level),'temp.bmp','jp2','compressionratio',Q);
    wb=imread('temp.bmp');
    control_group(:,:,level)=wb;
    wa=double(wb);
    ExWater=extractWater(wa,lenw,blocksize);
    wateronedim(level,:)=ExWater;  
    end
end


