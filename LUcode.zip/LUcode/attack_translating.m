function [wateronedim,control_group]=attack_translating(Q,P,watermarkedim,lenw,blocksize)

        watermarkedim=imread('watermarked.bmp');
        wb=TranslatingAttack(watermarkedim,Q,P);%平移到[x,y]   floor((M/10)*5)=50%
        wb=TranslatingAttack(wb,-Q,-P);
    for level=1:3   
        control_group(:,:,level)=wb(:,:,level);
        wa=double(wb(:,:,level));
        ExWater=extractWater(wa,lenw,blocksize);
        wateronedim(level,:)=ExWater;   
    end
end