function watermark=extract1(block1,block2)
   [L1,U1]=lu(block1)
   [L2,U2]=lu(block2)
   if  abs(L1(3,1)) >= abs(L2(3,1))
       watermark='1';
   else
       watermark='0';
   end
end