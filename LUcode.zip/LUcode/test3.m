clc
clear all;
block=[170,175,185,192;169,175,184,189;169,174,183,189;168,175,187,195];
[L,U]=lu(block)
result = 0;
count=1;
count2=1;
if result == 0
    num=1;
    for x=1:4
        for y=1:4
            S1(num,count)=L(x,y) ;
            num=num+1;
        end
    end
    count=count+1;
else
    num=1;
    for x=1:4
        for y=1:4
            S2(num,count2)=L(x,y);
            num=num+1;
        end
    end
    count2=count2+1;
end